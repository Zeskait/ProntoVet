export class Pet {
    constructor(public id: string, public name: string) { }
}